chrome.runtime.onInstalled.addListener(() => {
    console.log("Screen Recorder Extension installed.");
});
  